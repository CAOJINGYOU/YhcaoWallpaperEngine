# Privacy Policy

**Content of the privacy policy**

This application doesn’t:

-   Collect or use any personal information;
-   Store any personal data;
-   Share it to third parties.

**Changes to This Privacy Policy**

I may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. I will notify you of any changes by posting the new Privacy Policy on this page.

Last updated 2021-12-23
