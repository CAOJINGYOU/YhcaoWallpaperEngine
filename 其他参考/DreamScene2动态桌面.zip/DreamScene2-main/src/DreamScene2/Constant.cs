﻿namespace DreamScene2
{
    public static class Constant
    {
        public const string ProjectName = "DreamScene2";
        public const string Version = "1.4";
        public const string MainWindowTitle = ProjectName + " (～￣▽￣)～";
        public const string Cmd = "-c";
    }
}
