﻿namespace DreamScene2
{
    public class WebWindowOptions
    {
        public string UserDataFolder { get; set; }
        public bool DisableWebSecurity { get; set; }
    }
}
